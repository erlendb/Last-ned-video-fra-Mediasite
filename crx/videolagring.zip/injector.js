if (location.href.indexOf("mediasite.ntnu.no/Mediasite/Catalog/") != -1) {
	inject_catalog();
}
